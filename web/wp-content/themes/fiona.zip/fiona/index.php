<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Eleven
 */

?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
  "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"> 

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en"> 
<head> 
  <title>.:: Fiona ::.:: Sparking Together ::.</title> 
 
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/> 
  <meta http-equiv="description" content=""/> 
  
  <!-- Stylesheets --> 
  <link charset="utf-8" href="css/main.css" media="screen" rel="Stylesheet" title="Adele" type="text/css"/> 
  <link charset="utf-8" href="/css/print.css" media="print" rel="Stylesheet" type="text/css"/> 
  <style>@import url('/css/language/spanish.css');</style> 
  <link charset="utf-8" href="/css/ipad.css" media="only screen and (min-device-width: 481px) and (max-device-width: 1024px)" rel="Stylesheet" type="text/css" /> 
  
  <!-- Shortcut Icons --> 
  <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon"/> 
 
  <!-- RSS Feed --> 
  <link rel="alternate" title="Fiona RSS Feed" href="/rss-pr" type="application/rss+xml" /> 
 
  <!-- Scripts --> 
  <script src="/scripts/jquery-1.4.2.min.js" type="text/javascript"></script>  
  <script src="/scripts/jquery.backstretch.min.js" type="text/javascript"></script>  
  <script src="/scripts/jquery-ui-1.8.4.custom.min.js" type="text/javascript"></script>  
  <script src="/scripts/jquery.corner.js" type="text/javascript"></script>  
  <script src="/scripts/jquery.column.list.js" type="text/javascript"></script>  
  <script src="/scripts/jquery.cookie.js" type="text/javascript"></script>  
  <script src="/scripts/jquery.cycle.all.min.js" type="text/javascript"></script>  
  <script src="/scripts/jquery.touchwipe.min.js" type="text/javascript"></script> 
  <script src="/scripts/jqresize.js" type="text/javascript"></script> 
 
	<script src="/scripts/global.js" type="text/javascript"></script> 
      

</head> 

<body class="home"> 

	<script type="text/javascript"> 
	  var keywordGeoFoundIndex = 0; 
	</script> 
	<script src="scripts/background-gallery-script.js" type="text/javascript"></script> 
	
<!--Adobe Edge Runtime-->
    <script type="text/javascript" charset="utf-8" src="intro_edgePreload.js"></script>
    <script type="text/javascript" charset="utf-8" src="out_edgePreload.js"></script>
    <script type="text/javascript" charset="utf-8" src="standby_edgePreload.js"></script>
    <script type="text/javascript" charset="utf-8" src="chipsAnimation_edgePreload.js"></script>
<!--Adobe Edge Runtime End-->


<div id="wrapper" style="overflow:hidden;height: 942px;"> 

<div id="header"> 
	<div id="header_bg"><img id="header_bg_img" src="images/header4.png"></img></div>

   
</div><!-- end header --> 
	<div id="intro" class="EDGE-491969267" style="visibility:visible;"></div> 
	<div id="out" class="EDGE-68107672" style="visibility:hidden;position: relative;top: -401px;"></div>
	<div id="standby" class="EDGE-492073588" style="visibility:hidden;position: relative;top:-405px;"></div>
	<div id="chipsAnimation" class="EDGE-112784366" style="visibility:hidden;left: -30px;top: -430px;"></div>

</div>
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-21981783-1']);
  _gaq.push(['_setDomainName', '.adelerobots.com']);
  _gaq.push(['_trackPageview']);



  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();




 </script>
 
<!-- cargamos de wordpress el contenido de los chips-->

<div id="Titulos">
<?php

query_posts('order=asc');
// retrieve one post with an ID of 5
query_posts( 'p=0' );

// set $more to 0 in order to only get the first part of the post
global $more;
$more = 0;

// the Loop
while (have_posts()) : the_post();
	the_title();
	//the_content( 'Read the full post »' );
endwhile;
?>
</div>  

<div id="Contenidos">
<?php

query_posts('order=desc');
// retrieve one post with an ID of 5
query_posts( 'p<6' );

// set $more to 0 in order to only get the first part of the post
global $more;
$more = 0;

// the Loop
while (have_posts()) : the_post();
	//the_title();
	the_content( 'Read the full post »' );
endwhile;
?>
</div>  

</body> 
</html>  
